# 단어 임베딩 값 추출 후 Vector DB에 저장 => 오답에 유사어 제출 때 사용하기
import glob, json, os
import pandas as pd

from sentence_transformers import SentenceTransformer
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from backend.models import VocaLabels  # ← 모델 클래스 경로에 맞게 수정
from tqdm import tqdm
from dotenv import load_dotenv

# 1. SentenceTransformer 모델 로드
model = SentenceTransformer('BM-K/KoSimCSE-roberta-multitask', device='cuda')

load_dotenv()
DB_USER = os.getenv("DB_USER")
DB_PASSWORD = os.getenv("DB_PASSWORD")
DB_NAME = os.getenv("DB_NAME")

# 2. DB 연결
DATABASE_URL = f"postgresql+psycopg://{DB_USER}:{DB_PASSWORD}@localhost:5433/{DB_NAME}"
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(bind=engine)
session = SessionLocal()

# 3. csv 파일 읽기
csv_files = "./vocabulary_with_age.csv"
df = pd.read_csv(csv_files)

# 4. 데이터 삽입
for _, row in tqdm(df.iterrows(), total=len(df), desc="Embedding words"):
    word = row['어휘']
    pos = row['품사']
    meaning = row['의미']
    field = row['분야']
    difficulty = row['difficulty_score']
    assigned_age = row['assigned_age']

    # ✅ 의미 벡터화
    # 임베딩할 때 "의미"만이 아니라 "단어+의미" 조합
    embedding = model.encode(f"{word}: {meaning}").tolist()

    # ✅ DB에 객체 생성
    entry = VocaLabels(
        word=word,
        pos=pos,
        meaning=meaning,
        field=field,
        difficulty=difficulty,
        assigned_age=assigned_age,
        embedding=embedding
    )
    session.add(entry)

# ✅ 커밋
session.commit()
session.close()

print("✅ 단어 임베딩 DB 저장 완료!")
